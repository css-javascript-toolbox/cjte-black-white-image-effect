<script type="text/javascript">
    window.addEventListener('load', function() {
        // jQuery object reference.
        var $ = jQuery;
        $('#<?php echo $cb->containerElementId() ?> a')
        // Set CSS layout rules.
        .css({'position' : 'relative', 'display' : 'inline-block'})
        // Apply Black and White Effect Plugin.
        .BlackAndWhite(<?php echo $cb->params()->json() ?>);
    });
</script>
