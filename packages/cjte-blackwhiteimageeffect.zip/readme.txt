------------------------
CSS & JavaScript Toolbox
------------------------
URL: http://css-javascript-toolbox.com/scripts/
Version: 1.0
Date Added: 8th November 2013

Black And White Effect
------------------------------
This is a powerful jQuery script by WDS to create Black And White Effect.

Steps
-----
1) Click and download the Black And White Effect package
2) Click into the Packages section of the premium CJT V6 plugin
3) Press the Install Package button
4) Upload the package zip file
5) Go into the CJT V6 dashboard
6) Activate the code block titled: Black And White Effect
7) Edit the page or post where you want the Black And White Effect to appear
8) Click the CJT Block Shortcode button and select Black And White Effect
9) In-between the shortcode tags, add the content for Black And White Effect as in the example below.

Shortcode Example
-----------------
Example 1
[cjtoolbox name='Black And White Effect' hoverEffect=true webworkerPath=false responsive=true invertHoverEffect=false speed='{"fadein":200,"fadeout":800}']<a href="http://cjt.longestvision.com/6.0/unit-test/wp-content/uploads/2013/05/dogs-large.jpg"><img class="alignnone size-large wp-image-49" alt="Portrait of two young beauty dogs" src="http://cjt.longestvision.com/6.0/unit-test/wp-content/uploads/2013/05/dogs-large-1024x682.jpg" width="625" height="416" />[/cjtoolbox]
--------------------
Overview:-

parameters:

hoverEffect: To enable disable hover effect(boolean datatype)
hoverEffect: To enable disable webworkerpath(boolean datatype)
hoverEffect: To enable disable responsive(boolean datatype)
hoverEffect: To enable disable invertHoverEffect(boolean datatype)
fadeIn:To control the fadein speed(integer datatype)
fadeOut:To control the fadeout speed(integer datatype)



